<?php return array('dependencies' => array(), 'version' => 'ff534a17d5a4afbaadf5');
